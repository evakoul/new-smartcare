package com.example.application.entities;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "MedicalDocuments")
public class MedicalDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DocumentId")
    private Integer documentId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "PatientId", nullable = false)
    private Patient patient;

    @Column(name = "FileName", length = 255)
    private String fileName;

    @Column(name = "FilePath", length = 500)
    private String filePath;

    @Column(name = "UploadDate", nullable = false)
    private LocalDateTime uploadDate;

    @Column(name = "Extracted", nullable = false)
    private Boolean extracted;

    // Αυτό εκτελείται πριν γίνει insert στη βάση
    @PrePersist
    public void prePersist() {
        this.uploadDate = LocalDateTime.now();
        this.extracted = false;
    }

    // getters / setters

    public Integer getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Integer documentId) {
        this.documentId = documentId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public LocalDateTime getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(LocalDateTime uploadDate) {
        this.uploadDate = uploadDate;
    }

    public Boolean getExtracted() {
        return extracted;
    }

    public void setExtracted(Boolean extracted) {
        this.extracted = extracted;
    }
}