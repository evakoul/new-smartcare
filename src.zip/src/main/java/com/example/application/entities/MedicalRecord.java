package com.example.application.entities;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "MedicalRecords")
public class MedicalRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RecordId")
    private Integer recordId;

    @ManyToOne
    @JoinColumn(name = "PatientId")
    private Patient patient;

    @Column(name = "RecordType", length = 50)
    private String recordType;

    @Column(name = "CodeSystem", length = 50)
    private String codeSystem;

    @Column(name = "Code", length = 50)
    private String code;

    @Column(name = "Description", length = 255)
    private String description;

    @Column(name = "Value", length = 100)
    private String value;

    @Column(name = "Unit", length = 50)
    private String unit;

    @Column(name = "RecordDate")
    private LocalDateTime recordDate;

    @ManyToOne
    @JoinColumn(name = "CreatedFromDocumentId")
    private MedicalDocument createdFromDocument;

    public Integer getRecordId() {
        return recordId;
    }

    public void setRecordId(Integer recordId) {
        this.recordId = recordId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getCodeSystem() {
        return codeSystem;
    }

    public void setCodeSystem(String codeSystem) {
        this.codeSystem = codeSystem;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public LocalDateTime getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(LocalDateTime recordDate) {
        this.recordDate = recordDate;
    }

    public MedicalDocument getCreatedFromDocument() {
        return createdFromDocument;
    }

    public void setCreatedFromDocument(MedicalDocument createdFromDocument) {
        this.createdFromDocument = createdFromDocument;
    }
}