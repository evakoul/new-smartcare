package com.example.application.entities;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Doctors")
public class Doctor {

    @Id
    @Column(name = "DoctorId")
    private Integer doctorId;

    @OneToOne
    @MapsId
    @JoinColumn(name = "DoctorId")
    private User user;

    @Column(name = "Specialty", length = 100)
    private String specialty;

    @Column(name = "LicenseNumber", length = 50)
    private String licenseNumber;

   

    
    public Integer getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Integer doctorId) {
        this.doctorId = doctorId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

  

   
}



