package com.example.application.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.application.entities.SharedAccess;

public interface SharedAccessRepository 
        extends JpaRepository<SharedAccess, Integer> {

    // Φέρνει όλα τα ενεργά shares για συγκεκριμένο Doctor
    List<SharedAccess> findByDoctor_DoctorIdAndIsActiveTrue(Integer doctorId);

    // Φέρνει όλα τα shares για συγκεκριμένο Patient
    List<SharedAccess> findByPatient_PatientId(Integer patientId);

}