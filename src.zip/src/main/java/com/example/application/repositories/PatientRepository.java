package com.example.application.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.application.entities.Patient;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Integer> {

    Patient findByUser_UserId(Integer userId);

}