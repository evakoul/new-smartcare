package com.example.application.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.application.entities.MedicalDocument;

public interface MedicalDocumentRepository 
        extends JpaRepository<MedicalDocument, Integer> {

    List<MedicalDocument> findByPatient_PatientId(Integer patientId);

}