package com.example.application.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.application.entities.Doctor;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Integer> {

    Doctor findByLicenseNumber(String licenseNumber);

    java.util.List<Doctor> findBySpecialtyIgnoreCase(String specialty);

    // ✅ ΑΥΤΟ ΛΕΙΠΕΙ
    Doctor findByUser_UserId(Integer userId);
}
