package com.example.application.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.application.entities.MedicalRecord;

public interface MedicalRecordRepository 
        extends JpaRepository<MedicalRecord, Integer> {

    List<MedicalRecord> findByPatient_PatientId(Integer patientId);

}