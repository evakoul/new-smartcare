package com.example.application.services;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.application.entities.MedicalDocument;
import com.example.application.entities.Patient;

@Service
public class DocumentProcessingService {

    private static final Logger logger =
            LoggerFactory.getLogger(DocumentProcessingService.class);

    private final PdfService pdfService;
    private final AIService aiService;
    private final MedicalRecordService medicalRecordService;

    public DocumentProcessingService(
            PdfService pdfService,
            AIService aiService,
            MedicalRecordService medicalRecordService) {

        this.pdfService = pdfService;
        this.aiService = aiService;
        this.medicalRecordService = medicalRecordService;
    }

    public void processDocument(String filePath, Patient patient, MedicalDocument document) {

        try {

            System.out.println("Starting document processing...");
            System.out.println("File path: " + filePath);

            // 1. Extract text from PDF
            String text = pdfService.extractText(filePath);

            System.out.println("PDF TEXT:");
            System.out.println(text);

            if (text == null || text.trim().isEmpty()) {
                System.out.println("PDF text is empty. AI processing skipped.");
                return;
            }

            // 2. Send text to AI
            String aiResult = aiService.analyzeMedicalText(text);

            System.out.println("AI RESULT:");
            System.out.println(aiResult);

            if (aiResult == null || aiResult.trim().isEmpty()) {
                System.out.println("AI returned empty result. No record created.");
                return;
            }

            // 3. Create Medical Record
            medicalRecordService.createRecordFromAI(aiResult, patient, document);

            System.out.println("Medical record created successfully.");

        } catch (IOException | RuntimeException e) {

            logger.error("Error processing document", e);

        }
    }
}