package com.example.application.services;

import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AIService {

    private final RestTemplate restTemplate;

    public AIService() {
        this.restTemplate = new RestTemplate();
    }

    @SuppressWarnings("unchecked")
    public String analyzeMedicalText(String text) {

        String prompt = """
        Extract medical information from the following medical document.

        Return fields in this exact format:

        RecordType:
        CodeSystem:
        Code:
        Description:
        Value:
        Unit:
        Date:

        Medical Text:
        """ + text;

        Map<String, Object> request = Map.of(
                "model", "llama3",
                "prompt", prompt,
                "stream", false
        );

        String url = "http://localhost:11434/api/generate";

        Map<String, Object> response =
                (Map<String, Object>) restTemplate.postForObject(url, request, Map.class);

        if (response != null && response.containsKey("response")) {
            return response.get("response").toString();
        }

        return null;
    }
}