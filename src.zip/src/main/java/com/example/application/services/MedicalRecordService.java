package com.example.application.services;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.example.application.entities.MedicalDocument;
import com.example.application.entities.MedicalRecord;
import com.example.application.entities.Patient;
import com.example.application.repositories.MedicalRecordRepository;

@Service
public class MedicalRecordService {

    private final MedicalRecordRepository medicalRecordRepository;

    public MedicalRecordService(MedicalRecordRepository medicalRecordRepository) {
        this.medicalRecordRepository = medicalRecordRepository;
    }

    public MedicalRecord createRecordFromAI(String aiResult, Patient patient, MedicalDocument document) {

        MedicalRecord record = new MedicalRecord();

        String[] lines = aiResult.split("\n");

        for (String line : lines) {

            line = line.trim().replace("*", "");

            if (line.contains("RecordType:")) {
                record.setRecordType(line.split("RecordType:")[1].trim());
            }

            if (line.contains("CodeSystem:")) {
                record.setCodeSystem(line.split("CodeSystem:")[1].trim());
            }

            if (line.contains("Code:")) {
                record.setCode(line.split("Code:")[1].trim());
            }

            if (line.contains("Description:")) {
                record.setDescription(line.split("Description:")[1].trim());
            }

            if (line.contains("Value:")) {
                record.setValue(line.split("Value:")[1].trim());
            }

            if (line.contains("Unit:")) {
                record.setUnit(line.split("Unit:")[1].trim());
            }
        }

        record.setRecordDate(LocalDateTime.now());
        record.setPatient(patient);
        record.setCreatedFromDocument(document);

        return medicalRecordRepository.save(record);
    }
}