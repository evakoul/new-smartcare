package com.example.application.views;

import com.example.application.entities.User;
import com.example.application.repositories.UserRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.EmailField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;


@Route("forgot-password")
@CssImport("./styles/forgot-password.css")
@PageTitle("Ξέχασες τον Κωδικό;")
public class ForgotPasswordView extends VerticalLayout {

    private final UserRepository userRepository;

    
    public ForgotPasswordView(UserRepository userRepository) {
        this.userRepository = userRepository; 
        addClassName("forgot-password-view"); 

        setSizeFull();
        setAlignItems(Alignment.CENTER);
        setJustifyContentMode(JustifyContentMode.CENTER);

        EmailField emailField = new EmailField("Email");
        emailField.setRequiredIndicatorVisible(true);

        Button sendButton = new Button("Αποστολή Κωδικού");
        sendButton.addClickListener(event -> sendPassword(emailField.getValue()));

        VerticalLayout container = new VerticalLayout(emailField, sendButton);
        container.setAlignItems(Alignment.CENTER);
        container.getStyle()
                .set("background-color", "#0234")
                .set("border", "8px solid white")
                .set("border-radius", "10px")
                .set("padding", "25px")
                .set("width", "380px");

        add(container);
    }

    private void sendPassword(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            Notification.show("Το email δεν βρέθηκε!", 3000, Notification.Position.MIDDLE);
            return;
        }

        
        Notification.show("Ο κωδικός στάλθηκε στο email σας!", 3000, Notification.Position.MIDDLE);
        getUI().ifPresent(ui -> ui.navigate("login"));
    }
}
