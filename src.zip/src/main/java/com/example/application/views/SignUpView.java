package com.example.application.views;

import org.springframework.security.crypto.bcrypt.BCrypt;

import com.example.application.entities.Patient;
import com.example.application.entities.Role;
import com.example.application.entities.User;
import com.example.application.repositories.RoleRepository;
import com.example.application.repositories.UserRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.EmailField;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route("signup")
@CssImport("./styles/signup-view.css")
@PageTitle("Εγγραφή Χρήστη")
public class SignUpView extends VerticalLayout {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;


    private final TextField firstNameField = new TextField("Όνομα");
    private final TextField lastNameField = new TextField("Επώνυμο");
    private final EmailField emailField = new EmailField("Email");
    private final TextField phoneField = new TextField("Τηλέφωνο");
    private final PasswordField passwordField = new PasswordField("Κωδικός");
    private final PasswordField confirmPasswordField = new PasswordField("Επιβεβαίωση Κωδικού");
    private final Button registerButton = new Button("Εγγραφή");

    
   public SignUpView(UserRepository userRepository, RoleRepository roleRepository) {
    this.userRepository = userRepository;
    this.roleRepository = roleRepository;
addClassName("signup-view");
    buildUI();
}

    private void buildUI() {
        setSizeFull();
        setAlignItems(Alignment.CENTER);
        setJustifyContentMode(JustifyContentMode.CENTER);

        firstNameField.setWidthFull();
        lastNameField.setWidthFull();
        emailField.setWidthFull();
        phoneField.setWidthFull();
        passwordField.setWidthFull();
        confirmPasswordField.setWidthFull();
        registerButton.setWidthFull();
        registerButton.addClickListener(e -> registerUser());

        VerticalLayout form = new VerticalLayout(
                new H3("Εγγραφή Χρήστη"),
                firstNameField,
                lastNameField,
                emailField,
                phoneField,
                passwordField,
                confirmPasswordField,
                registerButton
        );

        form.setAlignItems(Alignment.CENTER);
        form.getStyle()
                .set("background-color", "#002234")
                .set("padding", "15px")
                .set("width", "360px")
                .set("border-radius", "10px")
                .set("max-height", "85vh")
        .set("overflow", "auto")
        .set("border-radius", "10px")
                .set("border", "8px solid white")
                .set("box-shadow", "0 4px 12px rgba(0,0,0,0.15)");

        add(form);
    }

    private void registerUser() {
    String firstName = firstNameField.getValue();
    String lastName = lastNameField.getValue();
    String email = emailField.getValue();
    String phone = phoneField.getValue();
    String password = passwordField.getValue();
    String confirmPassword = confirmPasswordField.getValue();

    if (firstName.isBlank() || lastName.isBlank() || email.isBlank()
            || password.isBlank() || confirmPassword.isBlank()) {
        Notification.show("Συμπληρώστε όλα τα πεδία!", 3000, Notification.Position.MIDDLE);
        return;
    }

    if (!password.equals(confirmPassword)) {
        Notification.show("Οι κωδικοί δεν ταιριάζουν!", 3000, Notification.Position.MIDDLE);
        return;
    }

    if (userRepository.existsByEmail(email)) {
        Notification.show("Το email υπάρχει ήδη!", 3000, Notification.Position.MIDDLE);
        return;
    }

    Role defaultRole = roleRepository.findByRoleName("Patient");
    if (defaultRole == null) {
        Notification.show("Ο ρόλος Patient δεν υπάρχει στη βάση!", 3000, Notification.Position.MIDDLE);
        return;
    }

    // Hash password
    String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

    
    User newUser = new User();
    newUser.setFirstName(firstName);
    newUser.setLastName(lastName);
    newUser.setEmail(email);
    newUser.setPhone(phone);
    newUser.setPasswordHash(hashedPassword);
    newUser.setRole(defaultRole);

    
    User savedUser = userRepository.save(newUser);

    Patient p = new Patient();
    p.setUser(savedUser);

    
    savedUser.setPatient(p);

    
    userRepository.save(savedUser);

    Notification.show("Ο λογαριασμός δημιουργήθηκε επιτυχώς!", 2500, Notification.Position.MIDDLE);

    getUI().ifPresent(ui ->
        ui.getPage().executeJs("setTimeout(() => window.location.href='login', 1500)")
    );
}

}









