package com.example.application.views;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route("")
@PageTitle("")
@CssImport("./styles/mainview.css")
public class MainView extends VerticalLayout {

    public MainView() {
        addClassName("main-container");
        setSpacing(true);
        setPadding(true);

        Button loginBtn = new Button("Login", VaadinIcon.USER.create());
        loginBtn.addClassName("login-btn");
        loginBtn.addClickListener(e ->
                getUI().ifPresent(ui -> ui.navigate("login"))
        );

        Button signupBtn = new Button("Sign Up", VaadinIcon.USER_CHECK.create());
        signupBtn.addClassName("signup-btn");
        signupBtn.addClickListener(e ->
                getUI().ifPresent(ui -> ui.navigate("signup"))
        );

        HorizontalLayout topBar = new HorizontalLayout(loginBtn, signupBtn);
        topBar.addClassName("top-bar");
        topBar.setSpacing(true);
        topBar.setPadding(false);
        topBar.setAlignItems(FlexComponent.Alignment.CENTER);
        add(topBar);

        Image logo = new Image("images/logo.png", "eCare Logo");
        logo.addClassName("logo");

        Paragraph tagline = new Paragraph("Η υγεία σου, παντού και πάντα στο χέρι σου.");
        tagline.addClassName("tagline");

        VerticalLayout titleBlock = new VerticalLayout(tagline);
        titleBlock.setPadding(false);
        titleBlock.setSpacing(false);

        HorizontalLayout header = new HorizontalLayout(logo, titleBlock);
        header.setWidthFull();
        header.setAlignItems(FlexComponent.Alignment.CENTER);
        header.setJustifyContentMode(FlexComponent.JustifyContentMode.START);
        header.addClassName("header");

        Button uploadBtn = new Button("Ανέβασμα Εγγράφων", new Icon(VaadinIcon.UPLOAD));
        uploadBtn.addClassName("btn-primary");
        uploadBtn.addClickListener(e ->
                getUI().ifPresent(ui -> ui.navigate("login"))
        );

        Button recordsBtn = new Button("Ιατρικός Φάκελος", new Icon(VaadinIcon.CLIPBOARD_TEXT));
        recordsBtn.addClassName("btn-outline");
        recordsBtn.addClickListener(e ->
                getUI().ifPresent(ui -> ui.navigate("login"))
        );

        HorizontalLayout actions = new HorizontalLayout(uploadBtn, recordsBtn);
        actions.addClassName("actions");
        actions.setAlignItems(Alignment.CENTER);

        Div card1 = createCard(
                VaadinIcon.FILE_TEXT,
                "Ανέβασμα Ιατρικών Εγγράφων",
                "Ανέβασε PDF όπως συνταγές, διαγνώσεις και αποτελέσματα εξετάσεων."
        );
        card1.addClickListener(e -> getUI().ifPresent(ui -> ui.navigate("login")));

        Div card2 = createCard(
                VaadinIcon.CLIPBOARD_TEXT,
                "Ιατρικό Ιστορικό",
                "Προβολή του πλήρους ηλεκτρονικού ιατρικού φακέλου."
        );
        card2.addClickListener(e -> getUI().ifPresent(ui -> ui.navigate("login")));

        Div card3 = createCard(
                VaadinIcon.USER_HEART,
                "Κοινοποίηση σε Γιατρό",
                "Μοιράσου τον ιατρικό φάκελο με τον γιατρό σου για προβολή."
        );
        card3.addClickListener(e -> getUI().ifPresent(ui -> ui.navigate("login")));

        card1.getStyle().set("cursor", "pointer");
        card2.getStyle().set("cursor", "pointer");
        card3.getStyle().set("cursor", "pointer");

        HorizontalLayout cards = new HorizontalLayout(card1, card2, card3);
        cards.addClassName("cards");
        cards.setWidthFull();
        cards.setSpacing(true);
        cards.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);

        add(header, actions, cards);
        setAlignItems(FlexComponent.Alignment.CENTER);
    }

    private Div createCard(VaadinIcon icon, String title, String desc) {
        Icon i = icon.create();
        i.addClassName("card-icon");

        H3 t = new H3(title);
        t.addClassName("card-title");

        Paragraph p = new Paragraph(desc);
        p.addClassName("card-desc");

        Div card = new Div(i, t, p);
        card.addClassName("feature-card");
        return card;
    }
}

