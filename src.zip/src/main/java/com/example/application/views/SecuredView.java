package com.example.application.views;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.example.application.entities.User;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.server.VaadinSession;

public abstract class SecuredView extends VerticalLayout implements BeforeEnterObserver {

    private final List<String> allowedRoles = new ArrayList<>();

    protected SecuredView(String... roles) {
        allowedRoles.addAll(Arrays.asList(roles));

        // Ο Admin έχει πάντα πρόσβαση
        if (!allowedRoles.contains("Admin")) {
            allowedRoles.add("Admin");
        }

        setSizeFull();
        setPadding(true);
        setSpacing(true);

        // Header με Logout button
        HorizontalLayout header = new HorizontalLayout();
        header.setWidthFull();
        header.setJustifyContentMode(JustifyContentMode.END);

        Button logoutButton = new Button("Logout", e -> logout());
        logoutButton.addClassName("logout-btn");

        header.add(logoutButton);
        add(header);

        // Session Timeout - 15 λεπτά αδράνειας
        VaadinSession.getCurrent().getSession().setMaxInactiveInterval(15 * 60);
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {

        User user = VaadinSession.getCurrent().getAttribute(User.class);

        if (user == null) {
            event.rerouteTo("login");
            return;
        }

        String role = user.getRole() != null ? user.getRole().getRoleName() : null;

        if (role == null || !allowedRoles.contains(role)) {
            VaadinSession.getCurrent().setAttribute(User.class, null);
            VaadinSession.getCurrent().close();
            event.rerouteTo("login"); // FIX ✔ Correct redirect
        }
    }

    private void logout() {
        VaadinSession.getCurrent().setAttribute(User.class, null);
        VaadinSession.getCurrent().close();
        UI.getCurrent().navigate("login"); // FIX ✔ Navigate server-side
    }
}






