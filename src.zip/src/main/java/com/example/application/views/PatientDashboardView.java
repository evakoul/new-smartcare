package com.example.application.views;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

import com.example.application.entities.Doctor;
import com.example.application.entities.MedicalDocument;
import com.example.application.entities.MedicalRecord;
import com.example.application.entities.Patient;
import com.example.application.entities.SharedAccess;
import com.example.application.entities.User;
import com.example.application.repositories.DoctorRepository;
import com.example.application.repositories.MedicalDocumentRepository;
import com.example.application.repositories.MedicalRecordRepository;
import com.example.application.repositories.PatientRepository;
import com.example.application.repositories.SharedAccessRepository;
import com.example.application.services.DocumentProcessingService;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;

@Route("patient-dashboard")
@PageTitle("Πίνακας Ασθενή")
@CssImport("./styles/patient-dashboard.css")
public class PatientDashboardView extends SecuredView {

    private final PatientRepository patientRepository;
    private final MedicalRecordRepository medicalRecordRepository;
    private final MedicalDocumentRepository medicalDocumentRepository;
    private final SharedAccessRepository sharedAccessRepository;
    private final DocumentProcessingService documentProcessingService;
    private final DoctorRepository doctorRepository;

    private Patient currentPatient;
    private User sessionUser;

    private final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final Grid<MedicalRecord> recordGrid = new Grid<>(MedicalRecord.class,false);
    private final Grid<MedicalDocument> documentGrid = new Grid<>(MedicalDocument.class,false);

    private final Span nameSpan = new Span();
    private final Span emailSpan = new Span();
    private final Span phoneSpan = new Span();

public PatientDashboardView(
        PatientRepository patientRepository,
        MedicalRecordRepository medicalRecordRepository,
        MedicalDocumentRepository medicalDocumentRepository,
        SharedAccessRepository sharedAccessRepository,
        DoctorRepository doctorRepository,
        DocumentProcessingService documentProcessingService
) {

        super("Patient");

        this.patientRepository = patientRepository;
        this.medicalRecordRepository = medicalRecordRepository;
        this.medicalDocumentRepository = medicalDocumentRepository;
        this.sharedAccessRepository = sharedAccessRepository;
        this.doctorRepository = doctorRepository;
        this.documentProcessingService = documentProcessingService;
        addClassName("patient-dashboard");

        setSizeFull();

        buildUI();
    }

    @Override
    protected void onAttach(AttachEvent attachEvent) {
        super.onAttach(attachEvent);
        loadData();
    }

    private void buildUI(){

        Tab profileTab = new Tab("Προφίλ Ασθενή");
        Tab recordsTab = new Tab("Ιστορικό Ασθενή");
        Tab documentsTab = new Tab("Ιατρικά Έγγραφα");
        Tab shareTab = new Tab("Κοινοποίηση Ιστορικού");

        Tabs tabs = new Tabs(profileTab,recordsTab,documentsTab,shareTab);

        Component profileContent = buildProfile();
        Component recordsContent = buildRecords();
        Component documentsContent = buildDocuments();
        Component shareContent = buildShareAccess();

        VerticalLayout content = new VerticalLayout(profileContent);

        tabs.addSelectedChangeListener(e -> {

            content.removeAll();

            if(e.getSelectedTab().equals(profileTab))
                content.add(profileContent);

            if(e.getSelectedTab().equals(recordsTab))
                content.add(recordsContent);

            if(e.getSelectedTab().equals(documentsTab))
                content.add(documentsContent);

            if(e.getSelectedTab().equals(shareTab))
                content.add(shareContent);
        });

        add(tabs,content);
    }

    private Component buildProfile(){

        VerticalLayout layout = new VerticalLayout();

        FormLayout form = new FormLayout();

        form.addFormItem(nameSpan,"Όνομα");
        form.addFormItem(emailSpan,"Email");
        form.addFormItem(phoneSpan,"Τηλέφωνο");

        Div profileBox = new Div(form);
        profileBox.getStyle()
                .set("border","1px solid #ccc")
                .set("padding","20px")
                .set("border-radius","10px")
                .set("max-width","400px");

        Button editBtn = new Button("Ρυθμίσεις Προφίλ", VaadinIcon.EDIT.create());
        editBtn.addClickListener(e -> openEditProfileDialog());

        layout.add(profileBox,editBtn);

        return layout;
    }

    private Component buildRecords(){

        VerticalLayout layout = new VerticalLayout();

        recordGrid.removeAllColumns();

        recordGrid.addColumn(MedicalRecord::getRecordId).setHeader("ID");

        recordGrid.addColumn(MedicalRecord::getDescription)
                .setHeader("Διάγνωση / Περιγραφή");

        recordGrid.addColumn(r ->
                r.getRecordDate()==null ? "-" : r.getRecordDate().format(dtf))
                .setHeader("Ημερομηνία");

        recordGrid.addComponentColumn(record -> {

            Button delete = new Button(VaadinIcon.TRASH.create());

            delete.addClickListener(e -> {

                medicalRecordRepository.delete(record);

                refreshRecords();

                Notification.show("Η εγγραφή διαγράφτηκε");
            });

            return delete;

        }).setHeader("Διαγραφή");

        Button addRecord = new Button("Προσθήκη Εγγραφής", VaadinIcon.PLUS.create());
        addRecord.addClickListener(e -> openAddRecordDialog());

        layout.add(addRecord,recordGrid);

        return layout;
    }

    private Component buildDocuments(){

        VerticalLayout layout = new VerticalLayout();

        documentGrid.removeAllColumns();

        documentGrid.addColumn(MedicalDocument::getDocumentId).setHeader("ID");

        documentGrid.addColumn(MedicalDocument::getFileName)
                .setHeader("Όνομα αρχείου");

        documentGrid.addComponentColumn(doc -> {

            if(doc.getFilePath()==null)
                return new Span("-");

            Anchor link = new Anchor(doc.getFilePath(),"Open PDF");
            link.setTarget("_blank");

            Button delete = new Button(VaadinIcon.TRASH.create());

            delete.addClickListener(e -> {

                File file = new File(doc.getFilePath());

                if(file.exists()){
                    file.delete();
                }

                medicalDocumentRepository.delete(doc);

                refreshDocuments();

                Notification.show("Το έγγραφο διαγράφτηκε");
            });

            return new HorizontalLayout(link,delete);

        }).setHeader("Actions");

        Upload upload = new Upload();
        upload.setAcceptedFileTypes("application/pdf");
        upload.setMaxFiles(1);

        UI ui = UI.getCurrent();

       upload.setUploadHandler(event -> {

    try{

        String originalFileName = event.getFileName();
        String uniqueName = UUID.randomUUID() + "_" + originalFileName;

        InputStream inputStream = event.getInputStream();

        File folder = new File("uploads");

        if(!folder.exists()){
            folder.mkdirs();
        }

        File file = new File(folder,uniqueName);

        try(FileOutputStream fos = new FileOutputStream(file)){

            byte[] buffer = new byte[1024];
            int bytesRead;

            while((bytesRead = inputStream.read(buffer)) != -1){
                fos.write(buffer,0,bytesRead);
            }
        }

        MedicalDocument doc = new MedicalDocument();
doc.setFileName(originalFileName);
doc.setFilePath("uploads/" + uniqueName);
doc.setPatient(currentPatient);

medicalDocumentRepository.save(doc);

documentProcessingService.processDocument(
        file.getAbsolutePath(),
        currentPatient,
        doc
);

        ui.access(() -> {

            Notification.show("Upload successful");

            refreshDocuments();
            refreshRecords();
        });

    }
    catch(IOException | RuntimeException e){

        ui.access(() ->
                Notification.show("Upload failed"));
    }
});

        layout.add(upload,documentGrid);

        return layout;
    }

    private Component buildShareAccess() {

        VerticalLayout layout = new VerticalLayout();

        ComboBox<Doctor> doctorCombo = new ComboBox<>("Επιλέξτε Γιατρό");

        doctorCombo.setItems(doctorRepository.findAll());

        doctorCombo.setItemLabelGenerator(
                doctor -> {
                    if(doctor.getUser()==null) return "Doctor";
                    String first = doctor.getUser().getFirstName()==null ? "" : doctor.getUser().getFirstName();
                    String last = doctor.getUser().getLastName()==null ? "" : doctor.getUser().getLastName();
                    return first + " " + last;
                }
        );

        Button shareBtn = new Button("Κοινοποίησε το ιστορικό μου");

        Button deleteBtn = new Button(VaadinIcon.TRASH.create());

        shareBtn.addClickListener(e -> {

            Doctor selectedDoctor = doctorCombo.getValue();

            if(selectedDoctor == null){
                Notification.show("Επιλέξτε γιατρό πρώτα");
                return;
            }

            SharedAccess sa = new SharedAccess();
            sa.setPatient(currentPatient);
            sa.setDoctor(selectedDoctor);
            sa.setGrantedAt(LocalDateTime.now());
            sa.setIsActive(true);

            sharedAccessRepository.save(sa);

            Notification.show("Το ιστορικό κοινοποιήθηκε");
        });

        deleteBtn.addClickListener(e -> {

            Doctor selectedDoctor = doctorCombo.getValue();

            if(selectedDoctor == null){
                Notification.show("Επιλέξτε γιατρό πρώτα");
                return;
            }

            List<SharedAccess> accesses =
                    sharedAccessRepository.findAll();

            for(SharedAccess sa : accesses){
                if(sa.getPatient().getPatientId().equals(currentPatient.getPatientId())
                        && sa.getDoctor().getDoctorId().equals(selectedDoctor.getDoctorId())){
                    sharedAccessRepository.delete(sa);
                }
            }

            Notification.show("Η κοινοποίηση διαγράφηκε");
        });

        layout.add(new HorizontalLayout(doctorCombo,shareBtn,deleteBtn));

        return layout;
    }

    private void loadData(){

        sessionUser = VaadinSession.getCurrent().getAttribute(User.class);

        if(sessionUser == null){

            UI.getCurrent().navigate("login");
            return;
        }

        currentPatient =
                patientRepository.findByUser_UserId(sessionUser.getUserId());

        if(currentPatient == null){

            Notification.show("Patient not found");
            return;
        }

        populateProfile();
        refreshRecords();
        refreshDocuments();
    }

    private void populateProfile(){

        if(currentPatient == null) return;

        User u = currentPatient.getUser();

        nameSpan.setText(currentPatient.getFullName()==null ? "" : currentPatient.getFullName());
        emailSpan.setText(currentPatient.getEmail()==null ? "" : currentPatient.getEmail());

        if(u != null)
            phoneSpan.setText(u.getPhone()==null ? "" : u.getPhone());
        else
            phoneSpan.setText("");
    }

    private void refreshRecords(){

        List<MedicalRecord> records =
                medicalRecordRepository
                        .findByPatient_PatientId(currentPatient.getPatientId());

        recordGrid.setItems(records);
    }

    private void refreshDocuments(){

        List<MedicalDocument> documents =
                medicalDocumentRepository
                        .findByPatient_PatientId(currentPatient.getPatientId());

        documentGrid.setItems(documents);
    }

    private void openAddRecordDialog(){

        Dialog dialog = new Dialog();

        ComboBox<String> recordType = new ComboBox<>("Record Type");
        recordType.setItems("Condition","Observation","Medication");

        ComboBox<String> codeSystem = new ComboBox<>("Code System");
        codeSystem.setItems("SNOMED","LOINC");

        TextField code = new TextField("Code");
        TextField description = new TextField("Description");
        TextField value = new TextField("Value");
        TextField unit = new TextField("Unit");

        DatePicker date = new DatePicker("Date");
        date.setValue(LocalDate.now());

        Button save = new Button("Save", e -> {

            if(description.isEmpty()){
                Notification.show("Συμπληρώστε περιγραφή");
                return;
            }

            MedicalRecord record = new MedicalRecord();

            record.setRecordType(recordType.getValue());
            record.setCodeSystem(codeSystem.getValue());
            record.setCode(code.getValue());
            record.setDescription(description.getValue());
            record.setValue(value.getValue());
            record.setUnit(unit.getValue());

            record.setRecordDate(
                    (date.getValue() == null ? LocalDate.now() : date.getValue())
                            .atStartOfDay()
            );

            record.setPatient(currentPatient);
            record.setCreatedFromDocument(null);

            medicalRecordRepository.save(record);

            Notification.show("Medical record created");

            dialog.close();

            refreshRecords();
        });

        dialog.add(new VerticalLayout(
                recordType,codeSystem,code,description,value,unit,date,save
        ));

        dialog.open();
    }

    private void openEditProfileDialog(){

        Dialog dialog = new Dialog();

        TextField fullName = new TextField("Ονοματεπώνυμο");
        fullName.setValue(currentPatient.getFullName()==null ? "" : currentPatient.getFullName());

        TextField email = new TextField("Email");
        email.setValue(currentPatient.getEmail()==null ? "" : currentPatient.getEmail());

        DatePicker dob = new DatePicker("Ημερομηνία Γέννησης");
        dob.setValue(currentPatient.getDateOfBirth());

        TextField gender = new TextField("Φύλο");
        gender.setValue(currentPatient.getGender()==null ? "" : currentPatient.getGender());

        TextField address = new TextField("Διεύθυνση");
        address.setValue(currentPatient.getAddress()==null ? "" : currentPatient.getAddress());

        TextField emergency = new TextField("Τηλέφωνο επικοινωνίας");
        emergency.setValue(currentPatient.getEmergencyContact()==null ? "" : currentPatient.getEmergencyContact());

        Button save = new Button("Save", e -> {

            currentPatient.setFullName(fullName.getValue());
            currentPatient.setEmail(email.getValue());
            currentPatient.setDateOfBirth(dob.getValue());
            currentPatient.setGender(gender.getValue());
            currentPatient.setAddress(address.getValue());
            currentPatient.setEmergencyContact(emergency.getValue());

            patientRepository.save(currentPatient);

            Notification.show("Το προφίλ ενημερώθηκε");

            dialog.close();

            loadData();
        });

        dialog.add(new VerticalLayout(
                fullName,email,dob,gender,address,emergency,save
        ));

        dialog.open();
    }
}






















