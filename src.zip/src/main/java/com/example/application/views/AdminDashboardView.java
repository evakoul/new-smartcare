package com.example.application.views;

import com.example.application.entities.Role;
import com.example.application.entities.User;
import com.example.application.repositories.RoleRepository;
import com.example.application.repositories.UserRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route("admin-dashboard")
@CssImport("./styles/admin-dashboard.css")
@PageTitle("Πίνακας Ελέγχου Διαχειριστή")
public class AdminDashboardView extends SecuredView {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    private Grid<User> userGrid;
    private FormLayout userForm;

    private TextField firstNameField;
    private TextField lastNameField;
    private TextField emailField;
    private ComboBox<Role> roleField;
    private Checkbox activeField;

    private User selectedUser;

    public AdminDashboardView(UserRepository userRepository,
                              RoleRepository roleRepository) {

        super("Admin");

        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        addClassName("admin-dashboard");

        setSizeFull();

        configureGrid();
        configureForm();

        VerticalLayout layout = new VerticalLayout(userGrid, userForm);
        layout.setSizeFull();
        layout.setPadding(true);
        layout.setSpacing(true);

        add(layout);
    }

    private void configureGrid() {

        userGrid = new Grid<>(User.class, false);
        userGrid.setWidthFull();
        userGrid.setHeight("400px");

        userGrid.addColumn(User::getUserId)
                .setHeader("ID")
                .setAutoWidth(true);

        userGrid.addColumn(User::getFirstName)
                .setHeader("First Name")
                .setAutoWidth(true);

        userGrid.addColumn(User::getLastName)
                .setHeader("Last Name")
                .setAutoWidth(true);

        userGrid.addColumn(User::getEmail)
                .setHeader("Email")
                .setAutoWidth(true);

        userGrid.addColumn(user ->
                user.getRole() != null ? user.getRole().getRoleName() : "")
                .setHeader("Role")
                .setAutoWidth(true);

        userGrid.addColumn(user ->
                Boolean.TRUE.equals(user.getIsActive()) ? "Active" : "Inactive")
                .setHeader("Status")
                .setAutoWidth(true);

        userGrid.setItems(userRepository.findAll());

        userGrid.asSingleSelect().addValueChangeListener(event -> {

            selectedUser = event.getValue();

            if (selectedUser != null) {
                populateForm(selectedUser);
            } else {
                clearForm();
            }
        });

        userGrid.addComponentColumn(user -> {

            boolean active = Boolean.TRUE.equals(user.getIsActive());

            Button toggle = new Button(active ? "Deactivate" : "Activate");

            toggle.addClickListener(e -> {

                user.setIsActive(!active);
                userRepository.save(user);

                userGrid.setItems(userRepository.findAll());

                Notification.show("User status updated");
            });

            return toggle;

        }).setHeader("Activation");
    }

    private void configureForm() {

        userForm = new FormLayout();
        userForm.setWidthFull();

        firstNameField = new TextField("First Name");
        lastNameField = new TextField("Last Name");
        emailField = new TextField("Email");

        roleField = new ComboBox<>("Role");
        roleField.setItemLabelGenerator(Role::getRoleName);

        roleField.setItems(
                roleRepository.findAll()
                        
        );

        activeField = new Checkbox("Active");

        Button saveButton = new Button("Save", e -> saveUser());

        userForm.add(
                firstNameField,
                lastNameField,
                emailField,
                roleField,
                activeField,
                saveButton
        );
    }

    private void saveUser() {

        if (selectedUser == null) {
            Notification.show("No user selected");
            return;
        }

        if (emailField.getValue().isEmpty()) {
            Notification.show("Email is required");
            return;
        }

        selectedUser.setFirstName(firstNameField.getValue());
        selectedUser.setLastName(lastNameField.getValue());
        selectedUser.setEmail(emailField.getValue());
        selectedUser.setRole(roleField.getValue());
        selectedUser.setIsActive(activeField.getValue());

        userRepository.save(selectedUser);

        userGrid.setItems(userRepository.findAll());

        Notification.show("User updated successfully");
    }

    private void populateForm(User user) {

        firstNameField.setValue(user.getFirstName() != null ? user.getFirstName() : "");
        lastNameField.setValue(user.getLastName() != null ? user.getLastName() : "");
        emailField.setValue(user.getEmail() != null ? user.getEmail() : "");

        roleField.setValue(user.getRole());

        activeField.setValue(Boolean.TRUE.equals(user.getIsActive()));
    }

    private void clearForm() {

        firstNameField.clear();
        lastNameField.clear();
        emailField.clear();
        roleField.clear();
        activeField.setValue(false);
    }
}












