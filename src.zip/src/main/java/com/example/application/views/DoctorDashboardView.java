package com.example.application.views;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.example.application.entities.MedicalDocument;
import com.example.application.entities.MedicalRecord;
import com.example.application.entities.Patient;
import com.example.application.entities.User;
import com.example.application.repositories.MedicalDocumentRepository;
import com.example.application.repositories.MedicalRecordRepository;
import com.example.application.repositories.PatientRepository;
import com.example.application.repositories.SharedAccessRepository;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H4;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;

@Route("doctor-dashboard")
@PageTitle("Πίνακας Γιατρού")
@CssImport("./styles/doctor-dashboard.css")
public class DoctorDashboardView extends SecuredView {

    private final SharedAccessRepository sharedAccessRepository;
    private final MedicalRecordRepository medicalRecordRepository;
    private final MedicalDocumentRepository medicalDocumentRepository;
    private final PatientRepository patientRepository;

    private Integer authenticatedDoctorUserId;

    private Grid<Patient> patientGrid;
    private Grid<MedicalRecord> recordGrid;
    private Grid<MedicalDocument> documentGrid;

    public DoctorDashboardView(
            SharedAccessRepository sharedAccessRepository,
            MedicalRecordRepository medicalRecordRepository,
            MedicalDocumentRepository medicalDocumentRepository,
            PatientRepository patientRepository
    ) {

        super("Doctor");

        this.sharedAccessRepository = sharedAccessRepository;
        this.medicalRecordRepository = medicalRecordRepository;
        this.medicalDocumentRepository = medicalDocumentRepository;
        this.patientRepository = patientRepository;
 addClassName("doctor-dashboard"); 
        buildUI();
    }

    @Override
    protected void onAttach(AttachEvent attachEvent) {
        super.onAttach(attachEvent);

        authenticatedDoctorUserId = getAuthenticatedUserId();

        if (authenticatedDoctorUserId == null) {
            Notification.show("Δεν βρέθηκε συνδεδεμένος γιατρός");
            return;
        }

        refreshPatients();
    }

    private void buildUI() {

        setSizeFull();
        addClassName("doctor-dashboard");

        createGrids();

      

        VerticalLayout patientCard = new VerticalLayout(
                new H4("Ασθενείς"),
                patientGrid
        );
        patientCard.addClassName("dashboard-card");

        VerticalLayout recordCard = new VerticalLayout(
                new H4("Ιατρικά Records"),
                recordGrid
        );
        recordCard.addClassName("dashboard-card");

        VerticalLayout documentCard = new VerticalLayout(
                new H4("Ιατρικά Έγγραφα (PDF / Συνταγές)"),
                documentGrid
        );
        documentCard.addClassName("dashboard-card");

        VerticalLayout layout = new VerticalLayout(
                
                patientCard,
                recordCard,
                documentCard
        );

        layout.setSizeFull();
        layout.setPadding(true);
        layout.setSpacing(true);

        add(layout);
    }

    private void createGrids() {

        // ================= PATIENT GRID =================

        patientGrid = new Grid<>(Patient.class, false);

        patientGrid.addColumn(Patient::getPatientId)
                .setHeader("ID")
                .setAutoWidth(true);

        patientGrid.addColumn(p -> {
            User u = p.getUser();
            return u != null
                    ? u.getFirstName() + " " + u.getLastName()
                    : "-";
        }).setHeader("Ονοματεπώνυμο")
          .setAutoWidth(true);

        patientGrid.setWidthFull();
        patientGrid.setHeight("250px");

        patientGrid.asSingleSelect().addValueChangeListener(event -> {

            Patient selected = event.getValue();

            if (selected != null) {
                loadMedicalData(selected);
            } else {
                recordGrid.setItems(new ArrayList<>());
                documentGrid.setItems(new ArrayList<>());
            }
        });

        // ================= RECORD GRID =================

        recordGrid = new Grid<>(MedicalRecord.class, false);

        recordGrid.addColumn(MedicalRecord::getRecordId)
                .setHeader("Record ID")
                .setAutoWidth(true);

        recordGrid.addColumn(MedicalRecord::getDescription)
                .setHeader("Description")
                .setAutoWidth(true);

        recordGrid.addColumn(MedicalRecord::getRecordDate)
                .setHeader("Date")
                .setAutoWidth(true);

        recordGrid.setWidthFull();
        recordGrid.setHeight("250px");

        // ================= DOCUMENT GRID =================

        documentGrid = new Grid<>(MedicalDocument.class, false);

        documentGrid.addColumn(MedicalDocument::getDocumentId)
                .setHeader("Document ID")
                .setAutoWidth(true);

        documentGrid.addColumn(MedicalDocument::getFileName)
                .setHeader("File Name")
                .setAutoWidth(true);

        documentGrid.addColumn(MedicalDocument::getUploadDate)
                .setHeader("Upload Date")
                .setAutoWidth(true);

        // ⭐ Column για άνοιγμα PDF
        documentGrid.addComponentColumn(doc -> {

            if (doc.getFilePath() == null) {
                return new H1("-");
            }

            Anchor link = new Anchor(doc.getFilePath(), "Open PDF");
            link.setTarget("_blank");
            link.addClassName("pdf-link");

            return link;

        }).setHeader("View Document");

        documentGrid.setWidthFull();
        documentGrid.setHeight("250px");
    }

    private void refreshPatients() {

        try {

            List<Integer> patientIds = sharedAccessRepository
                    .findByDoctor_DoctorIdAndIsActiveTrue(authenticatedDoctorUserId)
                    .stream()
                    .map(sa -> sa.getPatient().getPatientId())
                    .distinct()
                    .toList();

            if (patientIds.isEmpty()) {
                patientGrid.setItems(new ArrayList<>());
                return;
            }

            List<Patient> patients = patientRepository.findAllById(patientIds);

            patientGrid.setItems(patients);

        } catch (Exception ex) {
            Notification.show("Σφάλμα φόρτωσης ασθενών");
            System.err.println(ex.getMessage());
        }
    }

    private void loadMedicalData(Patient patient) {

        try {

            List<MedicalRecord> records = medicalRecordRepository
                    .findByPatient_PatientId(patient.getPatientId())
                    .stream()
                    .sorted(Comparator.comparing(
                            MedicalRecord::getRecordDate,
                            Comparator.nullsLast(Comparator.reverseOrder())
                    ))
                    .collect(Collectors.toList());

            recordGrid.setItems(records);

            List<MedicalDocument> documents = medicalDocumentRepository
                    .findByPatient_PatientId(patient.getPatientId())
                    .stream()
                    .sorted(Comparator.comparing(
                            MedicalDocument::getUploadDate,
                            Comparator.nullsLast(Comparator.reverseOrder())
                    ))
                    .collect(Collectors.toList());

            documentGrid.setItems(documents);

        } catch (Exception ex) {
            Notification.show("Σφάλμα φόρτωσης ιατρικών δεδομένων");
            System.err.println(ex.getMessage());
        }
    }

    private Integer getAuthenticatedUserId() {

        User user = VaadinSession.getCurrent().getAttribute(User.class);

        return user != null ? user.getUserId() : null;
    }
}







