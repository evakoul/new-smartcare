package com.example.application.views;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.application.entities.User;
import com.example.application.repositories.UserRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.login.LoginForm;
import com.vaadin.flow.component.login.LoginI18n;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;

@Route("login")
@PageTitle("Σύνδεση Χρήστη")
@CssImport("./styles/login-view.css")
public class LoginView extends VerticalLayout implements BeforeEnterObserver {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private final LoginForm loginForm = new LoginForm();

    public LoginView() {
        addClassName("login-view"); 
        setSizeFull();
        setAlignItems(Alignment.CENTER);
        setJustifyContentMode(JustifyContentMode.CENTER);

        loginForm.addLoginListener(e -> authenticate(e.getUsername(), e.getPassword()));
        loginForm.setForgotPasswordButtonVisible(false);
        loginForm.setI18n(createGreekText());

        Button forgotPasswordButton = new Button("Ξέχασες τον κωδικό σου;");
        forgotPasswordButton.getStyle()
                .set("background-color", "transparent")
                .set("color", "#0077ff")
                .set("text-decoration", "underline")
                .set("cursor", "pointer");

        forgotPasswordButton.addClickListener(e ->
                getUI().ifPresent(ui -> ui.navigate("forgot-password"))
        );

        VerticalLayout container = new VerticalLayout(loginForm, forgotPasswordButton);
        container.setAlignItems(Alignment.CENTER);
        container.getStyle()
                .set("background-color", "white")
                .set("border", "1px solid #0077ff")
                .set("border-radius", "10px")
                .set("padding", "25px")
                .set("width", "360px");

        add(container);
    }

    private void authenticate(String email, String rawPassword) {
        User user = userRepository.findByEmail(email);

        if (user == null) {
            loginForm.setError(true);
            return;
        }
        
if (!Boolean.TRUE.equals(user.getIsActive())) {
        loginForm.setError(true);
        Notification.show("Ο λογαριασμός είναι ανενεργός!", 3000, Notification.Position.MIDDLE);
        return;
    }

        if (!passwordEncoder.matches(rawPassword, user.getPasswordHash())) {
            loginForm.setError(true);
            return;
        }

        
        VaadinSession.getCurrent().setAttribute(User.class, user);

        redirectByRole(user);
    }

    private void redirectByRole(User user) {
    switch (user.getRole().getRoleName()) {
        case "Admin" -> getUI().ifPresent(ui -> ui.navigate("admin-dashboard"));
        case "Doctor" -> getUI().ifPresent(ui -> ui.navigate("doctor-dashboard"));
        case "Patient" -> getUI().ifPresent(ui -> ui.navigate("patient-dashboard"));
        default -> Notification.show("Άγνωστος ρόλος!", 3000, Notification.Position.MIDDLE);
    }
}

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        User loggedUser = VaadinSession.getCurrent().getAttribute(User.class);

        if (loggedUser != null) {
            redirectByRole(loggedUser);
        
        }
    }

    private LoginI18n createGreekText() {
        LoginI18n i18n = LoginI18n.createDefault();
        LoginI18n.Form form = i18n.getForm();
        form.setTitle("Σύνδεση Χρήστη");
        form.setUsername("Email");
        form.setPassword("Κωδικός");
        form.setSubmit("Σύνδεση");
        i18n.setForm(form);

        i18n.getErrorMessage().setTitle("Λανθασμένα στοιχεία!");
        i18n.getErrorMessage().setMessage("Ελέγξτε το email και τον κωδικό σας");
        i18n.setAdditionalInformation("Δεν έχεις λογαριασμό; Επικοινώνησε με τον διαχειριστή.");

        return i18n;
    }
}





