package com.example.application;

import java.sql.Connection;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class testconnection implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(testconnection.class);
    private final DataSource dataSource;

    public testconnection(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void run(String... args) {
        logger.info("Checking database connection...");

        try (Connection conn = dataSource.getConnection()) {
            if (conn != null && !conn.isClosed()) {
                logger.info("Connection successful!");
                logger.info("Database: {}", conn.getMetaData().getDatabaseProductName());
                logger.info("Version: {}", conn.getMetaData().getDatabaseProductVersion());
            } else {
                logger.error("Connection failed: connection is null or closed.");
            }
        } catch (Exception e) {
            logger.error("Connection failed!", e);
        }
    }
}


