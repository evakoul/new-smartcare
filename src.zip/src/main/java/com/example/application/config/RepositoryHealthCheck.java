package com.example.application.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public class RepositoryHealthCheck {

    @Bean
    public CommandLineRunner testAllRepositories(ApplicationContext ctx) {
        return args -> {
            System.out.println("\n🔍 Checking all repositories...\n");

            String[] beanNames = ctx.getBeanNamesForType(JpaRepository.class);

            for (String beanName : beanNames) {
                try {
                    JpaRepository<?, ?> repo = (JpaRepository<?, ?>) ctx.getBean(beanName);
                    long count = repo.count();
                    System.out.println("✔️ " + beanName + " OK (count=" + count + ")");
                } catch (DataAccessException | IllegalStateException ex) {
                    System.err.println("❌ " + beanName + " FAILED → " + ex.getMessage());
                }
            }

            System.out.println("\n📝 Repository check completed!\n");
        };
    }
}



